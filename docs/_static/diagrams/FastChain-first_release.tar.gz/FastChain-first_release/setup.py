try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup


if __name__ == '__main__':
    setup()
